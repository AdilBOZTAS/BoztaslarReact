export default function AdminMessageDetail() {
    return (
      <div>
        <h1>Message Detail</h1>
      </div>
    );
  }