export default function AdminProfile() {
    return (
      <div>
        <h1>User Profile</h1>
      </div>
    );
  }