export default function AdminProjectEdit() {
    return (
      <div>
        <h1>Edit Project</h1>
      </div>
    );
  }