export default function AdminMedia() {
    return (
      <div>
        <h1>Media Library</h1>
      </div>
    );
  }